"""Builds the in-app page and launcher icon from the web app files at the repository root."""
import os, re, shutil

root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
here = os.path.dirname(os.path.abspath(__file__))
s = open(os.path.join(root, 'index.html'), encoding='utf-8').read()

a = "const canShareFiles = (()=>{ try{"
assert a in s, 'web app page changed: share check not found'
s = s.replace(a, "const canShareFiles = window.MKAndroid ? true : (()=>{ try{", 1)
s = re.sub(r"\nif\('serviceWorker' in navigator\)\{[^\n]*\n", "\n", s)
css = open(os.path.join(here, 'android.css'), encoding='utf-8').read()
s = s.replace("[hidden]{display:none!important}", "[hidden]{display:none!important}\n" + css, 1)
js = open(os.path.join(here, 'android.js'), encoding='utf-8').read()
i = s.rindex("</script>")
s = s[:i] + js + s[i:]

assets = os.path.join(root, 'android', 'app', 'src', 'main', 'assets')
os.makedirs(assets, exist_ok=True)
open(os.path.join(assets, 'index.html'), 'w', encoding='utf-8').write(s)

icons = os.path.join(root, 'android', 'app', 'src', 'main', 'res', 'mipmap-xxxhdpi')
os.makedirs(icons, exist_ok=True)
shutil.copy(os.path.join(root, 'icon-192.png'), os.path.join(icons, 'ic_launcher.png'))
print('Prepared in-app page and icon')
