/* ---------- Android app: save to Gallery, share straight to WhatsApp, daily reminder ---------- */
if (window.MKAndroid) {
  $('dlBtn').hidden = false;
  $('dlBtn').textContent = 'Save to Gallery';
  $('saveBtn').onclick = () => {
    if (!lastRender) return;
    const r = MKAndroid.shareWhatsApp(state.key, lastRender.dataURL);
    if (r !== 'ok') toast('Couldn’t open WhatsApp (' + r + ').');
  };
  $('dlBtn').onclick = () => {
    if (!lastRender) return;
    const r = MKAndroid.saveToGallery(state.key, lastRender.dataURL);
    toast(r === 'ok' ? 'Saved to Gallery › Pictures › MK Morning Cards.' : 'Couldn’t save (' + r + ').');
  };
  $('howto').innerHTML = 'Every morning the app saves the day’s card to your <b>Gallery</b> and sends you a notification. Tap it and <b>WhatsApp</b> opens with the card attached — pick a contact, group or My status.';

  const box = document.createElement('div'); box.className = 'remind';
  box.innerHTML = '<label for="remTime">Daily card notification</label><input type="time" id="remTime">'
    + '<p class="sub" id="prepNote">Preparing upcoming cards…</p>'
    + '<button id="testNote">Send a test notification now</button>';
  $('howto').after(box);
  $('remTime').value = MKAndroid.getReminderTime();
  $('remTime').onchange = e => { if (e.target.value) { MKAndroid.setReminderTime(e.target.value); toast('Notification set for ' + e.target.value + ' every day.'); } };
  $('testNote').onclick = () => { MKAndroid.testNotification(); toast('Test notification sent. Check your notifications.'); };

  // Make the next 45 days of cards now, so the morning notification works even without opening the app.
  (async () => {
    await fontsReady;
    const fontsOk = document.fonts.check('700 40px "Playfair Display"') && document.fonts.check('500 40px "Cormorant Garamond"');
    const days = fontsOk ? 45 : 2;           // offline: make only today and tomorrow, retry with proper fonts next time
    let ready = 0;
    for (let i = 0; i < days; i++) {
      const d = new Date(); d.setDate(d.getDate() + i); const k = keyOf(d);
      if (!MKAndroid.hasCard(k)) {
        const out = await renderCard(k);
        MKAndroid.storeCard(k, out.dataURL);
        await new Promise(r => setTimeout(r, 20));
      }
      ready++;
    }
    const last = new Date(); last.setDate(last.getDate() + days - 1);
    $('prepNote').textContent = fontsOk
      ? 'Cards are ready until ' + fmt(keyOf(last), {day:'numeric', month:'short'}) + '. Open the app now and then to keep them coming.'
      : 'No internet for fonts right now, so only today’s and tomorrow’s cards are ready. Open the app again when online.';
  })();
}
