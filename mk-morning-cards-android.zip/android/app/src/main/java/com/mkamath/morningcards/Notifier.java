package com.mkamath.morningcards;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;

/** Saves today's card to the Gallery and posts the "tap to share on WhatsApp" notification. */
final class Notifier {
    static final String CHANNEL = "daily_card";
    private static final int NOTIFICATION_ID = 100;

    private Notifier() {}

    static void ensureChannel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Daily Good Morning card",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Your Good Morning card, ready to share on WhatsApp");
            nm.createNotificationChannel(ch);
        }
    }

    static void deliver(Context c) {
        ensureChannel(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        String key = CardStore.todayKey();

        Intent open = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(c, 2, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xFFE3BD78)
                .setAutoCancel(true);

        boolean ready = false;
        if (CardStore.has(c, key)) {
            try {
                byte[] data = CardStore.read(c, key);
                Uri uri = CardStore.saveToGallery(c, key, data);
                Intent share = CardStore.whatsappIntent(c, uri);
                share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                PendingIntent sharePi = PendingIntent.getActivity(c, 3, share,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                Bitmap full = BitmapFactory.decodeByteArray(data, 0, data.length);
                Bitmap small = Bitmap.createScaledBitmap(full, 540, 540, true);

                b.setContentTitle("Good Morning card is ready")
                        .setContentText("Saved to Gallery. Tap to share on WhatsApp.")
                        .setLargeIcon(small)
                        .setStyle(new Notification.BigPictureStyle()
                                .bigPicture(small)
                                .bigLargeIcon((Bitmap) null))
                        .setContentIntent(sharePi)
                        .addAction(new Notification.Action.Builder(
                                Icon.createWithResource(c, R.drawable.ic_stat),
                                "Share to WhatsApp", sharePi).build())
                        .addAction(new Notification.Action.Builder(
                                Icon.createWithResource(c, R.drawable.ic_stat),
                                "Open app", openPi).build());
                ready = true;
            } catch (Exception e) {
                ready = false;
            }
        }
        if (!ready) {
            b.setContentTitle("Good Morning")
                    .setContentText("Open MK Morning Cards to prepare today's card.")
                    .setContentIntent(openPi);
        }

        boolean allowed = Build.VERSION.SDK_INT < 33
                || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        if (allowed) nm.notify(NOTIFICATION_ID, b.build());
        CardStore.prune(c);
    }
}
