package com.mkamath.morningcards;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import java.util.Locale;

/** Lets the card page (JavaScript) save, store and share cards through Android. */
public class Bridge {
    private final Activity activity;

    Bridge(Activity activity) {
        this.activity = activity;
    }

    private static byte[] decode(String data) {
        int comma = data.indexOf(',');
        String b64 = comma >= 0 ? data.substring(comma + 1) : data;
        return Base64.decode(b64, Base64.DEFAULT);
    }

    @JavascriptInterface
    public boolean hasCard(String key) {
        return CardStore.has(activity, key);
    }

    @JavascriptInterface
    public void storeCard(String key, String data) {
        try {
            CardStore.put(activity, key, decode(data));
        } catch (Exception ignored) {
            // a missing card only means the notification asks to open the app
        }
    }

    @JavascriptInterface
    public String saveToGallery(String key, String data) {
        try {
            CardStore.saveToGallery(activity, key, decode(data));
            return "ok";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    @JavascriptInterface
    public String shareWhatsApp(String key, String data) {
        try {
            Uri uri = CardStore.saveToGallery(activity, key, decode(data));
            final Intent intent = CardStore.whatsappIntent(activity, uri);
            activity.runOnUiThread(() -> activity.startActivity(intent));
            return "ok";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    @JavascriptInterface
    public String getReminderTime() {
        int[] t = Scheduler.time(activity);
        return String.format(Locale.US, "%02d:%02d", t[0], t[1]);
    }

    @JavascriptInterface
    public void setReminderTime(String hhmm) {
        try {
            String[] parts = hhmm.split(":");
            Scheduler.setTime(activity, Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
        } catch (Exception ignored) {
            // keep the previous time if the value is malformed
        }
    }

    @JavascriptInterface
    public void testNotification() {
        final android.content.Context app = activity.getApplicationContext();
        new Thread(() -> Notifier.deliver(app)).start();
    }
}
