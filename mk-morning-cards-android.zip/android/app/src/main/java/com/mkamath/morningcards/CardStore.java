package com.mkamath.morningcards;

import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** Keeps pre-made cards in app storage, saves them to the Gallery and builds the WhatsApp share intent. */
final class CardStore {
    static final String ALBUM = "MK Morning Cards";

    private CardStore() {}

    static String keyFor(Date d) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d);
    }

    static String todayKey() {
        return keyFor(new Date());
    }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "cards");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static File file(Context c, String key) {
        return new File(dir(c), key + ".jpg");
    }

    static boolean has(Context c, String key) {
        File f = file(c, key);
        return f.exists() && f.length() > 0;
    }

    static void put(Context c, String key, byte[] data) throws IOException {
        File tmp = new File(dir(c), key + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(data);
        }
        File f = file(c, key);
        if (f.exists()) f.delete();
        if (!tmp.renameTo(f)) throw new IOException("Could not store card");
    }

    static byte[] read(Context c, String key) throws IOException {
        return Files.readAllBytes(file(c, key).toPath());
    }

    /** Deletes cards older than three days. */
    static void prune(Context c) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -3);
        String cutoff = keyFor(cal.getTime());
        File[] files = dir(c).listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.getName().compareTo(cutoff) < 0) f.delete();
        }
    }

    /** Saves the card to Pictures/MK Morning Cards and returns its Gallery address. */
    static Uri saveToGallery(Context c, String key, byte[] data) throws IOException {
        String name = "good-morning-" + key + ".jpg";
        String relPath = Environment.DIRECTORY_PICTURES + "/" + ALBUM + "/";
        ContentResolver cr = c.getContentResolver();
        Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);

        String selection = MediaStore.Images.Media.DISPLAY_NAME + "=? AND "
                + MediaStore.Images.Media.RELATIVE_PATH + "=?";
        try (Cursor cur = cr.query(collection, new String[]{MediaStore.Images.Media._ID},
                selection, new String[]{name, relPath}, null)) {
            if (cur != null && cur.moveToFirst()) {
                Uri existing = ContentUris.withAppendedId(collection, cur.getLong(0));
                write(cr, existing, data);
                return existing;
            }
        }

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, relPath);
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri uri = cr.insert(collection, values);
        if (uri == null) throw new IOException("Gallery refused the image");
        write(cr, uri, data);
        ContentValues done = new ContentValues();
        done.put(MediaStore.Images.Media.IS_PENDING, 0);
        cr.update(uri, done, null, null);
        return uri;
    }

    private static void write(ContentResolver cr, Uri uri, byte[] data) throws IOException {
        try (OutputStream out = cr.openOutputStream(uri, "wt")) {
            if (out == null) throw new IOException("Could not open Gallery file");
            out.write(data);
        }
    }

    private static boolean installed(Context c, String pkg) {
        try {
            c.getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /** Opens WhatsApp's contact picker with the card attached (falls back to the share menu). */
    static Intent whatsappIntent(Context c, Uri uri) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("image/jpeg");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.setClipData(ClipData.newRawUri("Good Morning card", uri));
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (installed(c, "com.whatsapp")) {
            send.setPackage("com.whatsapp");
            return send;
        }
        if (installed(c, "com.whatsapp.w4b")) {
            send.setPackage("com.whatsapp.w4b");
            return send;
        }
        return Intent.createChooser(send, "Share Good Morning card");
    }
}
