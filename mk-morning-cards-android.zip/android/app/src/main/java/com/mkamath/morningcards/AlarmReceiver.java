package com.mkamath.morningcards;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fires every morning: sets tomorrow's alarm, then delivers today's card. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        final Context app = context.getApplicationContext();
        Scheduler.schedule(app);
        final PendingResult result = goAsync();
        new Thread(() -> {
            try {
                Notifier.deliver(app);
            } finally {
                result.finish();
            }
        }).start();
    }
}
