package com.mkamath.morningcards;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Puts the daily alarm back after a restart, app update or clock change. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Scheduler.schedule(context.getApplicationContext());
    }
}
